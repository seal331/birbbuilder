#pragma once
extern void isrs_install();
