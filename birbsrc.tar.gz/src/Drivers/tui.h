#pragma once

#include "../common.h"

/* bool __set__;
int clickTimer;
bool showMenu; */
/* bool showWeekday;
bool showTestWindow;
int testWindowX;
int testWindowY;
bool __drag; int __prevX;
int __prevY;
int __grabX;
 int renderdelay; */

void terminalRenderTask(int taskno);
